# BAI-ONE — Memory Prototype 001

An Android Studio source project for the first BAI-ONE memory prototype.

## Included
- Android launcher app (`com.baione.memory`)
- Original Memory Prototype 001 interface bundled in the app
- Device-local browser storage for saved memories
- Search, categories, individual deletion, and delete-all control
- Encrypted `.bai` backup and restore using AES-GCM / PBKDF2 in the prototype
- Android document picker integration for saving and opening `.bai` backups
- GitHub Actions workflow to build a debug APK

## Important limitations
- This is a prototype, not a sentient AI, brain interface, or autonomous assistant.
- Memories remain on this device; there is no login, cloud sync, or multi-device sharing.
- Keep the backup passphrase safe. A lost passphrase means the encrypted backup cannot be restored.
- The Android project has been packaged as source. It has **not yet been compiled or tested on a physical phone**.
- Before public distribution, perform device testing, review security and privacy, and create a signed release build and privacy policy.

## Build on GitHub using a phone
1. Upload the **contents** of this ZIP to the root of a repository named `BAI-ONE`.
2. Make sure `.github/workflows/android.yml` remains at that exact path.
3. Open the repository's **Actions** tab and enable workflows if prompted.
4. Choose **Build BAI-ONE Android APK** and tap **Run workflow**.
5. When the run succeeds, open it and download the `BAI-ONE-debug-apk` artifact.
6. Extract the artifact ZIP; install `app-debug.apk` on your Android phone.

## Project structure
- `app/src/main/` — Android app source and bundled web interface
- `.github/workflows/android.yml` — cloud APK build
- `build.gradle`, `settings.gradle` — Gradle project configuration
